# إجازاتي
Android WebView application for employee leave records.

The APK is built by GitHub Actions: open Actions, run Build Android APK, then download the `ejazati-apk` artifact.
